﻿using System;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Web.UI;

public partial class sql_async2 : Page
{
    public const string ConnString = "Data Source=.;Integrated Security=True;Async=True";

    protected async void Page_PreRender(object sender, EventArgs e)
    {
        using (SqlConnection conn = new SqlConnection(ConnString))
        {
            conn.Open();
            using (SqlCommand cmd = new SqlCommand("WAITFOR DELAY '00:00:01'", conn))
            {
                await Task.Factory.FromAsync<int>(cmd.BeginExecuteNonQuery,
                                                  cmd.EndExecuteNonQuery, null);
            }
        }
    }
}