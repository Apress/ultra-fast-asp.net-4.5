﻿using System;
using System.Net;
using System.Text;
using System.Web.UI;

public partial class webreq1 : Page
{
    protected async void Page_Load(object sender, EventArgs e)
    {
        WebRequest request = WebRequest.Create("http://www.apress.com/");
        WebResponse response = await request.GetResponseAsync();
        StringBuilder sb = new StringBuilder();
        foreach (string header in response.Headers.Keys)
        {
            sb.Append(header);
            sb.Append(": ");
            sb.Append(response.Headers[header]);
            sb.Append("<br/>");
        }
        this.LO.Text = sb.ToString();
    }
}
