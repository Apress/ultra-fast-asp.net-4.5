﻿using System;
using System.Web.UI;
using TerraServer;

public partial class terra1 : Page
{
    protected async void Page_Load(object sender, EventArgs e)
    {
        var terra = new TerraServiceSoapClient();
        Place place = new Place()
        {
            City = "Seattle",
            State = "WA",
            Country = "US"
        };
        var result = await terra.GetPlaceFactsAsync(place);
        PlaceFacts facts = result.Body.GetPlaceFactsResult;
        this.LA.Text = String.Format("Latitude: {0:0.##}", facts.Center.Lat);
        this.LO.Text = String.Format("Longitude: {0:0.##}", facts.Center.Lon);
    }
}
