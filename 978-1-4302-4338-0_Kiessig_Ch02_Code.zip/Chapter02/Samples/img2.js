var qimg = '<img src="q1.gif" height="16" width="16" />';
