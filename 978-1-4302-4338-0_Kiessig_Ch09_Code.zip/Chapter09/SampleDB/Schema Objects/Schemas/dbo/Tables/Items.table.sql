﻿CREATE TABLE [dbo].[Items] (
    [ItemId]          INT          IDENTITY (1, 1) NOT NULL,
    [ItemName]        VARCHAR (64) NULL,
    [ItemCategory]    VARCHAR (32) NULL,
    [ItemSubcategory] VARCHAR (32) NULL
);

