﻿CREATE TABLE [dbo].[Votes](
	[VoteId] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NULL,
	[ItemId] [int] NULL,
	[VoteValue] [int] NULL,
	[VoteTime] [datetime] NULL,
 CONSTRAINT [VotesPK] PRIMARY KEY CLUSTERED 
(
	[VoteId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


