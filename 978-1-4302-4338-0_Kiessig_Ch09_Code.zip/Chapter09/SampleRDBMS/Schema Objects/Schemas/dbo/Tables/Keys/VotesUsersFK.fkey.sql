﻿ALTER TABLE [dbo].[Votes]  WITH CHECK ADD  CONSTRAINT [VotesUsersFK] FOREIGN KEY([UserId])
REFERENCES [dbo].[Users] ([UserId])


GO
ALTER TABLE [dbo].[Votes] CHECK CONSTRAINT [VotesUsersFK]

