﻿ALTER TABLE [dbo].[Votes]  WITH CHECK ADD  CONSTRAINT [VotesItemsFK] FOREIGN KEY([ItemId])
REFERENCES [dbo].[Items] ([ItemId])


GO
ALTER TABLE [dbo].[Votes] CHECK CONSTRAINT [VotesItemsFK]

