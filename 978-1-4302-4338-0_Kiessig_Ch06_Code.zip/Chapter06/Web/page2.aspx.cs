﻿using System;
using System.Web.UI;

public partial class page2 : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.Master.Header = "My Header";
    }
}