﻿using System;
using System.Web.UI;
using Samples;

public partial class resize1 : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ImageResizer.ResizeImage(this.Server.MapPath("~/launch.jpg"),
                                 this.Server.MapPath("~/launch_th.jpg"), 150.0, 60);
    }
}