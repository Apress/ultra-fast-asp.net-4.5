﻿using System;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.Adapters;

namespace Samples
{
    public class NoIdControlAdapter : WebControlAdapter
    {
        protected override void Render(HtmlTextWriter writer)
        {
            PageBase page = this.Page as PageBase;
            if ((page != null) && page.RemoveIds && 
                (this.Control.ClientIDMode != ClientIDMode.Static))
            {
                HtmlTextWriter noIdwriter = new NoIdHtmlWriter(writer);
                base.RenderBeginTag(noIdwriter);
                base.RenderContents(writer);
                base.RenderEndTag(noIdwriter);
            }
            else
            {
                base.Render(writer);
            }
        }
    }

    public class NoIdHtmlWriter : HtmlTextWriter
    {
        public NoIdHtmlWriter(TextWriter writer)
            : base(writer)
        {
        }

        public override void AddAttribute(HtmlTextWriterAttribute key, string value)
        {
            if (key != HtmlTextWriterAttribute.Id)
                base.AddAttribute(key, value);
        }
    }
}
