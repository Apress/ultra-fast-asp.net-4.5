﻿using System;
using System.Web.UI;

public partial class Controls_Frame : UserControl
{
    public string HeaderText { get; set; }
    private FrameContainer Container { get; set; }

    [TemplateContainer(typeof(FrameContainer))]
    [PersistenceMode(PersistenceMode.InnerProperty)]
    public ITemplate HeaderTemplate { get; set; }

    [TemplateInstance(TemplateInstance.Single)]
    [PersistenceMode(PersistenceMode.InnerProperty)]
    public ITemplate BodyTemplate { get; set; }

    protected override void OnInit(EventArgs e)
    {
        if (this.HeaderTemplate != null)
        {
            this.Container = new FrameContainer();
            this.HeaderTemplate.InstantiateIn(this.Container);
            this.header.Controls.Add(this.Container);
        }
        if (this.BodyTemplate != null)
        {
            this.BodyTemplate.InstantiateIn(this.center);
        }
    }

    protected override void OnPreRender(EventArgs e)
    {
        base.OnPreRender(e);
        this.Container.HeaderText = this.HeaderText;
        this.Container.DataBind();
    }
}

public class FrameContainer : Control, INamingContainer
{
    public string HeaderText { get; set; }
}
