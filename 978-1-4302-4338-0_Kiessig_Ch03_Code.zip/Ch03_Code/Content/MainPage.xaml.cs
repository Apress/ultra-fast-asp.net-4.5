﻿using System;
using System.IO.IsolatedStorage;
using System.Windows.Browser;
using System.Windows.Controls;

namespace Content
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            HtmlPage.RegisterScriptableObject("Page", this);
            InitializeComponent();
        }

        [ScriptableMember]
        public string WelcomeMessage()
        {
            string name = null;
            IsolatedStorageSettings.SiteSettings.TryGetValue("welcome", out name);
            if (!String.IsNullOrEmpty(name))
            {
                return String.Format(
                    "Welcome back, {0}<div><a href=\"WelcomeTestPage.aspx\">Logout</a></div>", 
                    HttpUtility.HtmlEncode(name));
            }
            else
            {
                return "<a href=\"WelcomeTestPage.aspx\">Login</a>";
            }
        }
    }
}
