﻿using System;
using System.Web;
using System.Web.UI;

public partial class proxy1 : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        TimeSpan age = TimeSpan.FromSeconds(60.0);
        this.Response.Cache.SetMaxAge(age);
        this.Response.Cache.SetExpires(DateTime.UtcNow + age);
        this.Response.Cache.SetLastModified(DateTime.UtcNow);
        this.Response.Cache.SetCacheability(HttpCacheability.Public);
        this.Response.Cache.SetNoServerCaching();
    }
}
