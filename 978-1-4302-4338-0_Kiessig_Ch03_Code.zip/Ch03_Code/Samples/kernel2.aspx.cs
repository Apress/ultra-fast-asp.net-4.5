﻿using System;
using System.Web;
using System.Web.UI;

public partial class kernel2 : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        TimeSpan age = TimeSpan.FromDays(1.0);
        this.Response.Cache.SetMaxAge(age);
        this.Response.Cache.SetExpires(DateTime.UtcNow + age);
        this.Response.Cache.SetLastModified(DateTime.UtcNow);
        this.Response.Cache.SetCacheability(HttpCacheability.Public);
        this.Response.Cache.SetSlidingExpiration(true);
    }
}
