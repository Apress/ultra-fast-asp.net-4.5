﻿using System;
using System.Web.Caching;
using System.Web.UI;

public partial class cache1 : Page
{
    public static readonly Object lockObject = new Object();
    private const string myKey = "keyx";

    protected void Page_Load(object sender, EventArgs e)
    {
        bool isFromCache = true;
        string result = null;
        lock (lockObject)
        {
            result = this.Cache[myKey] as string;
            if (result == null)
            {
                isFromCache = false;
                result = DateTime.Now.ToString();
                this.Cache.Add(myKey, result, null, DateTime.UtcNow.AddSeconds(5),
                               Cache.NoSlidingExpiration, CacheItemPriority.High, null);
            }
        }
        this.status.Text = String.Format("{0} {1}", result, isFromCache ? "is from cache" : "is not from cache");
    }
}
