﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web;
using System.Web.Caching;

namespace Samples
{
    public class Global : HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            string cs = ConfigurationManager.ConnectionStrings["data"].ConnectionString;
            //
            // This requires enabling Service Broker:
            //      alter database [Sample] set enable_broker with rollback immediate
            //
            //SqlDependency.Start(cs);
            HttpRuntime.Cache.Insert("key", "value", null,
                    DateTime.MaxValue, Cache.NoSlidingExpiration,
                    CacheItemPriority.NotRemovable, null);
        }

        protected void Application_Stop(object sender, EventArgs e)
        {
            string cs = ConfigurationManager.ConnectionStrings["data"].ConnectionString;
            //SqlDependency.Stop(cs);
            HttpRuntime.Cache.Remove("key");
        }

        public override string GetOutputCacheProviderName(HttpContext context)
        {
            if (context.Request.Url.AbsolutePath.EndsWith("provider2.aspx"))
            {
                return "MemoryCacheProvider";
            }
            return base.GetOutputCacheProviderName(context);
        }

        public override string GetVaryByCustomString(HttpContext context, string arg)
        {
            if (arg == "info")
            {
                HttpCookie cookie = context.Request.Cookies[arg];
                return cookie == null ? String.Empty : cookie.Value;
            }
            return base.GetVaryByCustomString(context, arg);
        }
    }
}