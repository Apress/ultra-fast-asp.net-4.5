﻿using System;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Web;
using System.Web.UI;
using Samples;

public partial class depend2 : Page
{
    public const string SqlDependencyCookie = "MS.SqlDependencyCookie";

    protected void Page_Load(object sender, EventArgs e)
    {
        //
        // See Install-Instructions.txt for details on how to enable this functionality
        //
        var context = new DataClasses();
        var depend = new SqlDependency();
        var oldCookie = CallContext.GetData(SqlDependencyCookie);
        try
        {
            CallContext.SetData(SqlDependencyCookie, depend.Id);
            depend.OnChange += depend_OnChange;
            var query = from info in context.MyInfos select info;
            var result = query.ToArray();
            mygrid.DataSource = result;
            mygrid.DataBind();
        }
        finally
        {
            CallContext.SetData(SqlDependencyCookie, oldCookie);
        }
    }

    static void depend_OnChange(object sender, SqlNotificationEventArgs e)
    {
        HttpResponse.RemoveOutputCacheItem("/depend2.aspx");
    }
}
