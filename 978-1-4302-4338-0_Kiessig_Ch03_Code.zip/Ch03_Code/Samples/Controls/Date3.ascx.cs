﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Caching;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Controls_Date3 : UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        CacheDependency depend = new CacheDependency(this.MapPath("~/depend.txt"));
        this.CachePolicy.Dependency = depend;
    }
}
