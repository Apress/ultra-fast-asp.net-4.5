﻿using System;
using System.IO.IsolatedStorage;
using System.Windows;
using System.Windows.Browser;
using System.Windows.Controls;

namespace Welcome
{
    public partial class MainPage : UserControl
    {
        public const string WelcomeKey = "welcome";

        public MainPage()
        {
            this.Loaded += new RoutedEventHandler(Page_Loaded);
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            string name = null;
            IsolatedStorageSettings.SiteSettings.TryGetValue(WelcomeKey, out name);
            UpdateUI(name);
        }

        private void UpdateUI(string name)
        {
            bool show;
            if (String.IsNullOrEmpty(name))
            {
                this.Message.Text = "Please Login";
                this.UserName.Visibility = Visibility.Visible;
                this.LoginButton.Content = "Login";
                show = false;
            }
            else
            {
                this.Message.Text = "Welcome back, " + name;
                this.UserName.Visibility = Visibility.Collapsed;
                this.LoginButton.Content = "Logout";
                show = true;
            }
            HtmlElement div = HtmlPage.Document.GetElementById("message");
            if (div != null)
            {
                div.SetStyleAttribute("display", show ? "block" : "none");
            }
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string name = null;
            if (this.UserName.Visibility == Visibility.Collapsed)
            {
                //
                // Logout
                //
                IsolatedStorageSettings.SiteSettings.Remove(WelcomeKey);
            }
            else
            {
                name = this.UserName.Text;
                if (!String.IsNullOrEmpty(name))
                {
                    //
                    // Login
                    //
                    IsolatedStorageSettings.SiteSettings[WelcomeKey] = name;
                }
            }
            IsolatedStorageSettings.SiteSettings.Save();
            UpdateUI(name);
        }
    }
}
