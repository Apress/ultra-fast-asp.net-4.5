﻿UPDATE [dbo].[ConfigInfo]
	SET [Strval] = 'CD'
	WHERE [Key] = 'CookieName' 