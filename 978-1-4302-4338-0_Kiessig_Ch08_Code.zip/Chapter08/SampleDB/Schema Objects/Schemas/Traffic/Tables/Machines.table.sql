﻿CREATE TABLE [Traffic].[Machines] (
    [MachineId]    UNIQUEIDENTIFIER NULL,
    [CreationDate] DATETIME         NULL
);

