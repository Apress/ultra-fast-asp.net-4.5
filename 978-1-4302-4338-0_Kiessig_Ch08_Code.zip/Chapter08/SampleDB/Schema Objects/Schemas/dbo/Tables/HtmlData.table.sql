﻿CREATE TABLE [dbo].[HtmlData] (
    [id]   INT           IDENTITY (1, 1) NOT NULL,
    [Html] VARCHAR (MAX) NULL
);

