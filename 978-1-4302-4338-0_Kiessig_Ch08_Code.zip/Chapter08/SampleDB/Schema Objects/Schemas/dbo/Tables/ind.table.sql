﻿CREATE TABLE [dbo].[ind] (
    [v1] INT          IDENTITY (1, 1) NOT NULL,
    [v2] INT          NULL,
    [v3] VARCHAR (64) NULL
);

