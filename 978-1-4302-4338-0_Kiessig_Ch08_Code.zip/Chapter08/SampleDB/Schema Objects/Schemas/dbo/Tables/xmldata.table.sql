﻿CREATE TABLE [dbo].[xmldata] (
    [id]   INT IDENTITY (1, 1) NOT NULL,
    [data] XML NULL
);

