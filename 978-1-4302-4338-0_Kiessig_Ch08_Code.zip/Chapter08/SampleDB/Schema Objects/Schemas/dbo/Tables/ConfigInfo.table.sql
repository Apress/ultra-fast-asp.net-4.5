﻿CREATE TABLE [dbo].[ConfigInfo] (
    [Key]    VARCHAR (64)  NOT NULL,
    [Strval] VARCHAR (256) NULL
);

