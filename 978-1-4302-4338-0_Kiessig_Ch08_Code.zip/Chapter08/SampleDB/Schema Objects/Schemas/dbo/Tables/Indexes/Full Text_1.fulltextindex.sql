﻿CREATE FULLTEXT INDEX ON [dbo].[xmldata]
    ([data] LANGUAGE 1033)
    KEY INDEX [dataPK]
    ON [SearchCatalog];

