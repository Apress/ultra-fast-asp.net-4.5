﻿CREATE TABLE [dbo].[TextInfo] (
    [Id]    INT             IDENTITY (1, 1) NOT NULL,
    [Email] NVARCHAR (256)  NULL,
    [Quote] NVARCHAR (1024) NULL,
    [Info]  VARCHAR (2048)  NULL
);

