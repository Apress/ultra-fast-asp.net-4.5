﻿CREATE TYPE [dbo].[PageViewType] AS  TABLE (
    [UserId] UNIQUEIDENTIFIER NULL,
    [PvUrl]  VARCHAR (256)    NOT NULL);

