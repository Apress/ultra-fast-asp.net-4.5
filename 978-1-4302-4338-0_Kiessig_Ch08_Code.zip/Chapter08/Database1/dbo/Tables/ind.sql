﻿CREATE TABLE [dbo].[ind] (
    [v1] INT          IDENTITY (1, 1) NOT NULL,
    [v2] INT          NULL,
    [v3] VARCHAR (64) NULL
);


GO
CREATE UNIQUE CLUSTERED INDEX [IndIX]
    ON [dbo].[ind]([v1] ASC);


GO
CREATE UNIQUE NONCLUSTERED INDEX [IndV2IX]
    ON [dbo].[ind]([v2] ASC);

