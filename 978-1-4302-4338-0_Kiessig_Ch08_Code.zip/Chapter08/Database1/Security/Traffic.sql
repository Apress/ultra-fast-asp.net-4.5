﻿CREATE SCHEMA [Traffic]
    AUTHORIZATION [dbo];

