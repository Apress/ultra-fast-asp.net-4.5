﻿using System.Data;
using System.Data.SqlClient;

namespace Samples
{
    public class PageViews
    {
        public const string ConnString =
            "Data Source=server;Initial Catalog=Sample;Integrated Security=True";

        public PageViews()
        {
            this.Count = -1;
        }

        public int GetCount()
        {
            return this.Count;
        }

        public DataTable GetRows(int startRowIndex, int maximumRows)
        {
            bool needCount = false;
            if (this.Count == -1)
            {
                needCount = true;
            }
            DataTable data = new DataTable();
            using (SqlConnection conn = new SqlConnection(ConnString))
            {
                using (SqlCommand cmd = new SqlCommand("[Traffic].[PageViewRows]", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameterCollection p = cmd.Parameters;
                    p.Add("startrow", SqlDbType.Int).Value = startRowIndex + 1;
                    p.Add("pagesize", SqlDbType.Int).Value = maximumRows;
                    p.Add("getcount", SqlDbType.Bit).Value = needCount;
                    p.Add("count", SqlDbType.Int).Direction = ParameterDirection.Output;
                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        data.Load(reader);
                        if (needCount)
                        {
                            this.Count = (int)cmd.Parameters["count"].Value;
                        }
                    }
                }
            }
            return data;
        }

        public int Count { get; set; }
    }
}