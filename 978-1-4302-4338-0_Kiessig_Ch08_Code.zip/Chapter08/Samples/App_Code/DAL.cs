﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Threading.Tasks;

namespace Samples
{
    public static class DAL
    {
        public static string SampleDBConnectionString
        {
            get { return "Data Source=server;Initial Catalog=Sample;Integrated Security=True"; }
        }

        public static IAsyncResult AddBrowserBegin(RequestInfo info,
            AsyncCallback callback)
        {
            SqlConnection conn =
                new SqlConnection(ConfigData.TrafficConnectionStringAsync);
            SqlCommand cmd = new SqlCommand("[Traffic].[AddBrowser]", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("id", SqlDbType.UniqueIdentifier).Value = info.BrowserId;
            cmd.Parameters.Add("agent", SqlDbType.VarChar, 256).Value = info.Agent;
            conn.Open();
            return cmd.BeginExecuteNonQuery(callback, cmd);
        }

        public static void AddBrowserEnd(IAsyncResult ar)
        {
            using (SqlCommand cmd = ar.AsyncState as SqlCommand)
            {
                if (cmd != null)
                {
                    try
                    {
                        cmd.EndExecuteNonQuery(ar);
                    }
                    catch (SqlException e)
                    {
                        EventLog.WriteEntry("Application",
                            "Error in AddBrowser: " + e.Message,
                            EventLogEntryType.Error, 103);
                        throw;
                    }
                    finally
                    {
                        cmd.Connection.Dispose();
                    }
                }
            }
        }

        public static async void AddBrowser(RequestInfo info)
        {
            using (SqlConnection conn =
                new SqlConnection(ConfigData.TrafficConnectionStringAsync))
            {
                using (SqlCommand cmd = new SqlCommand("[Traffic].[AddBrowser]", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("id", SqlDbType.UniqueIdentifier).Value = info.BrowserId;
                    cmd.Parameters.Add("agent", SqlDbType.VarChar, 256).Value = info.Agent;
                    await conn.OpenAsync();
                    await cmd.ExecuteNonQueryAsync();
                }
            }
        }
    }
}