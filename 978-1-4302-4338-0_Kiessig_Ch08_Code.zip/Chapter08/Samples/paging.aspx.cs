﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using Samples;

public partial class paging : Page
{
    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);
        this.RegisterRequiresControlState(this);
    }

    protected override void OnLoad(EventArgs e)
    {
        base.OnLoad(e);
        if (!this.IsPostBack)
        {
            this.Count = -1;
        }
    }

    protected override void LoadControlState(object savedState)
    {
        if (savedState != null)
        {
            this.Count = (int)savedState;
        }
    }

    protected override object SaveControlState()
    {
        return this.Count;
    }

    protected void PageViewSource_ObjectCreated(object sender, ObjectDataSourceEventArgs e)
    {
        PageViews pageViews = e.ObjectInstance as PageViews;
        if (pageViews != null)
        {
            pageViews.Count = this.Count;
        }
    }

    protected void PageViewSource_ObjectDisposing(object sender, ObjectDataSourceDisposingEventArgs e)
    {
        PageViews pageViews = e.ObjectInstance as PageViews;
        if (pageViews != null)
        {
            this.Count = pageViews.Count;
        }
    }

    public int Count { get; set; }
}