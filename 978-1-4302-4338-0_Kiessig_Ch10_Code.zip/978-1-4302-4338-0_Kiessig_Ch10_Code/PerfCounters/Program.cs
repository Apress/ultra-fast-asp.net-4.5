﻿using System.Diagnostics;
using System.Threading;

namespace Samples
{
    class Program
    {
        static void Main(string[] args)
        {
            if (PerfCounters.Create())
            {
                for (int i = 0; i < 1000; i++)
                {
                    PerfCounters.IncrementLogins();
                    Thread.Sleep(100);
                }
            }
            else
            {
                PerfCounters.Delete();
            }
        }
    }

    public static class PerfCounters
    {
        public static readonly string CategoryName = "Membership";

        public static bool Create()
        {
            if (!PerformanceCounterCategory.Exists(CategoryName))
            {
                var ccd = new CounterCreationData("Logins", "Number of logins",
                    PerformanceCounterType.NumberOfItems32);
                var ccdc = new CounterCreationDataCollection();
                ccdc.Add(ccd);
                ccd = new CounterCreationData("Ave Users", "Average number of users",
                    PerformanceCounterType.AverageCount64);
                ccdc.Add(ccd);
                ccd = new CounterCreationData("Ave Users base", "Average number of users base",
                    PerformanceCounterType.AverageBase);
                ccdc.Add(ccd);
                PerformanceCounterCategory.Create(CategoryName, "Website Membership system",
                    PerformanceCounterCategoryType.MultiInstance, ccdc);
                return true;
            }
            else
            {
                return false;
            }
        }

        public static void Delete()
        {
            if (PerformanceCounterCategory.Exists(CategoryName))
            {
                PerformanceCounterCategory.Delete(CategoryName);
            }
        }

        public static void IncrementLogins()
        {
            var numLogins = new PerformanceCounter(CategoryName, "Logins", "MyAppInstance", false);
            numLogins.Increment();
        }
    }
}
