﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class template1 : MyBaseClass
{
    protected override void OnLoad(EventArgs e)
    {
        base.OnLoad(e);
        //
        // Your code here
        //
    }
}
